void VisualInitialization(void);

